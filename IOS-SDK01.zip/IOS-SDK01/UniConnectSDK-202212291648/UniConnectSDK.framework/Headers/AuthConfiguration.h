//
//  AuthConfiguration.h
//  SecoSDK
//
//  Created by leagsoft on 2022/9/5.
//  Copyright © 2022 Huawei. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef enum : NSUInteger {
    AuthTypeAccountPwd, //用户名密码
    AuthTypeAnonymous,//匿名登录
    AuthTypeCert,//证书挑战
    AuthTypeCertAccountPwd,//证书+用户名密码
    AuthTypeUnknow = 100,   //未知类型
} AuthType;


@interface AuthConfiguration : NSObject
@property (nonatomic, assign) AuthType authType;

@property (nonatomic, copy) NSString *userName;//用户名
@property (nonatomic, copy) NSString *password;//密码
@property (nonatomic, copy) NSString *certPath;
@property (nonatomic, copy) NSString *certPassword;
@property (nonatomic, assign) BOOL isCACheck;
@property (nonatomic, assign) NSString * caCertFilePath;


@end

NS_ASSUME_NONNULL_END
