//
//  UniConnectErrorCode.h
//  UniConnectSDK
//
//  Created by dengjian on 2022/9/24.
//  Copyright © 2022 Huawei. All rights reserved.
//

#ifndef UniConnectErrorCode_h
#define UniConnectErrorCode_h

typedef enum : NSUInteger {
    TunnelModeReliable,//可靠模式
    TunnelModeFast,//快速模式
    TunnelModeAdaptive,//自适应模式
} TunnelMode;



typedef enum : NSUInteger {
    ConnectErrorCodeSucceed         = 1100,        //创建连接成功
    ConnectErrorCodeFailed          = 1106,        //连接失败
    ConnectErrorCodeNotInit         = 1107,        //SDK未初始化
    
    ConnectErrorCodeParamError,                     //参数错误
    ConnectErrorCodeStatusRefuse,                   //连接未返回结果，又调用连接
    ConnectErrorCodeRepeat,                         //配置名称重复
    ConnectErrorCodeInvalid,                        //配置不全或格式有误
    ConnectErrorCodeUserRefuse,                     //首次保存配置到系统vpn配置时，用户拒绝。需要用户同意并输入终端锁屏密码
} ConnectErrorCode;


typedef enum : NSUInteger {
    AuthResultCodeSucceed               = 1200, // 登录成功
    AuthResultVerityServerFailed        = 1201, // 开启可信证书校验时，校验失败
    AuthResultCodeFirstLoginError       = 1202, // 首次密码登陆,需要修改
    AuthResultCodeSMSCheckWarning       = 1203, // 需要进行双因子验证
    AuthResultCodeLoginFailed           = 1204, // 登录失败
    AuthResultCodeUserExpireWeakError   = 1205, // 您的密码已过期，请改用网页登陆，并修改密码
    AuthResultCodeStatusRefuse          = 1206, //当前非等待授权状态
    AuthResultCodeCNEMFailed            = 1207, //网络扩展失败
    AuthResultCodeNotSupportUDP         = 1106, //Udp隧道建立失败
    
//    AuthResultCodeUserPasswordError,
//    AuthResultCodeUserLockedError,
//    AuthResultCodeUserOverTopError,


} AuthResultCode;

typedef enum : NSUInteger {
    SendRequestResultCodeSucceed,
    SendRequestResultCodeFailed,
} SendRequestResultCode;



typedef enum : NSUInteger {
    DeleteConnectionConfigurationResultCodeSucceed, // 删除配置成功
    DeleteConnectionConfigurationResultCodeFailed,  // 删除配置失败
} DeleteConnectionConfigurationResultCode;




typedef enum : NSUInteger {
    VerificationCodeResultCodeSucceed           = 1300,   //双因子登陆成功
    VerificationCodeResultCodeFailed            = 1301, //双因子验证失败
    VerificationCodeResultCodeStatusRefuse      = 1302,  //当前非等待双因子认证状态
} VerificationCodeResultCode;

typedef enum : NSUInteger {
    ModifyPasswordResultCodeSucceed                     = 999,                  //修改密码成功
    ModifyPasswordResultCodeOldPwdError                 = 1000,                 //旧密码错误
    ModifyPasswordResultCodeIsLowError                  = 1001,                 //修改密码时新密码不符合低密码策略
    ModifyPasswordResultCodeIsMiddleError               = 1002,                 //修改密码时新密码不符合中密码策略
    ModifyPasswordResultCodeIsHighError                 = 1003,                 //修改密码时新密码不符合高密码策略
    ModifyPasswordResultCodeFailed                      = 1004,                 //其他错误
    ModifyPasswordResultCodePasswordFmtError            = 1005,                 //密码格式错误
    ModifyPasswordResultCodeNewVerifyPasswordDiffError  = 1006,                 //新密码和确认密码不一致
    ModifyPasswordResultCodeNewPasswordSameError        = 1007,                 //新密码和旧密码一致
    ModifyPasswordResultCodeNotEnabled                  = 1008,                 //不允许修改密码


//    ModifyPasswordResultCodeLenError = 1001,
//    ModifyPasswordResultCodeNumNumError,
//    ModifyPasswordResultCodeCharNumError,
//    ModifyPasswordResultCodeNamePwError,
//    ModifyPasswordResultCodeNoMixLowerUpper,
//
//    ModifyPasswordResultCodeRenewPwError,
//    ModifyPasswordResultCodeFailBecauseSaving,
//    ModifyPasswordResultCodeNotEnabled,
} ModifyPasswordResultCode;





typedef enum : NSUInteger {
    VPNStatusInvalid = 0,                   // 未开始
    VPNStatusDisconnected = 1,              // 未连接
    VPNStatusConnecting = 2,                // 连接中
    VPNStatusConnected = 3,                 // 已连接
    VPNStatusReasserting = 4,               // 重连中
    VPNStatusDisconnecting = 5,             // 断开连接中
    VPNStatusConnectingWaitAuth = 6,        // 等待授权
    VPNStatusConnectingWaitAuthSMS = 7,     // 等待二次认证
} VPNStatus;




#endif /* UniConnectErrorCode_h */
