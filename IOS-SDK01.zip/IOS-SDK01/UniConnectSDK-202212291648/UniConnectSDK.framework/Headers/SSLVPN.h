//
//  SSLVPN.h
//  SecoSDK
//
//  Created by SDK on 2019/7/19.
//  Copyright © 2019年 Huawei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <NetworkExtension/NetworkExtension.h>

#import <UniConnectSDK/ConnectionConfiguration.h>
#import <UniConnectSDK/AuthConfiguration.h>
#import <UniConnectSDK/UniConnectErrorCode.h>



@class ConnectionConfiguration;
@class AuthConfiguration;

NS_ASSUME_NONNULL_BEGIN



@protocol VPNStatusDelegate <NSObject>

//VPN 连接状态回调，如果需要授权
- (void)didVPNStatusChanged:(VPNStatus)vpnStatus data:(_Nullable id)data;

@end



@interface SSLVPN : NSObject

// VPN连接回调
@property(nonatomic,weak)id<VPNStatusDelegate>delegate;

// VPN连接状态
@property(nonatomic,assign) VPNStatus vpnStatus;

/**
 获取管理类单例对象
 @return 管理类单例对象
 */
+ (SSLVPN *)shareInstance;


/**
 初始化SSLVPN
 @param bundleId 创建PacketTunnel的bundleIdetify
 */
- (BOOL)initWithPacketTunnelBundleId:(NSString *)bundleId;

/**
 设置日志路径
 @param path  日志存放路径
 @param level  日志等级 （1,2,3,4）
 */
- (BOOL)initLog:(NSString *)path loglevel:(int)level;


/**
 连接
 @param config  连接配置
 @param complete  连接结果回调
 */
- (void)startConnectWithConfig:(ConnectionConfiguration *)config
                      complete:(void (^)(ConnectErrorCode, id))complete;


/**
 根据配置名称删除配置
 @param configName  配置名称
 @param complete  删除结果回调
 */
- (void)deleteConfigWithName:(NSString *)configName
                    complete:(void (^)(DeleteConnectionConfigurationResultCode))complete;


/**
 授权
 @param config  授权配置
 @param complete  授权结果回调
 */
- (void)startAuthWithConfig:(AuthConfiguration*)config
                   complete:(void(^)(AuthResultCode code))complete;

/**
 关闭VPN连接
 */
- (void)disconnect;


/**
 修改密码
 @param oldPassword 旧密码
 @param newPassword 新密码
 @param verifyPassword 再次确认新密码
 @param complete 修改密码结果回调
 */
- (void)modifyPasswordWithOldPassword:(NSString *)oldPassword
                        toNewPassword:(NSString *)newPassword
                       verifyPassword:(NSString *)verifyPassword
                             complete:(nullable void (^)(ModifyPasswordResultCode code))complete;

/**
 双因子认证
 @param verificationCode 验证码
 @param complete 双因子认证结果
 */
- (void)verificationCode:(NSString *)verificationCode
                complete:(void(^)(VerificationCodeResultCode code))complete;

/**
 获取日志的文件夹绝对路径
 */
- (NSString *)getLogPath;

- (void)collectLogComplete:(nullable void (^)(BOOL success))complete;

-(void)pingTunnel:(nullable void (^)(NSString * resp))complete;

@end

NS_ASSUME_NONNULL_END
