//
//  ConnectionConfiguration.h
//  SecoClientVPN
//
//  Created by xz on 2017/7/26.
//  Copyright © 2017年 work. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum : NSUInteger {
    RELIABLE_TRANSFER_MODE,//可靠模式
    FAST_TRANSFER_MODE,//快速模式
    ADAPTIVE_TANSFER_MODE,//自适应模式
} TRANSFER_MODE;

@interface ConnectionConfiguration : NSObject
//@property (nonatomic, copy) NSString *userName;//用户名
//@property (nonatomic, copy) NSString *password;//密码
@property (nonatomic, copy) NSString *connectionName;//连接名字
@property (nonatomic, copy) NSString *connectionType;//连接类型
@property (nonatomic, copy) NSString *serverAddress;//远程网关地址 
@property (nonatomic, copy) NSString *serverPort;//端口
@property (nonatomic, assign) TRANSFER_MODE transferMode;//隧道模式
@property (nonatomic, assign) BOOL autoReconnect;
@property (nonatomic, assign) BOOL isSecurity;//是否开启国密：0关闭 1开启 默认关闭
@property (nonatomic, assign) BOOL isRoute;//是否开启路由覆盖：0关闭 1开启 默认开启
@property (nonatomic, assign) BOOL isTCPBuffer;//是否开启TCP缓冲区：0关闭 1开启 默认关闭
@property (nonatomic, assign) BOOL isAutoGateway;//是否开启站点优选：0关闭 1开启 默认关闭
@property (nonatomic, copy) NSString *smSignPath;//国密签名证书路径 开启国密功能必传
@property (nonatomic, copy) NSString *smEncPath;//国密加密证书路径 开启国密功能必传
@property (nonatomic, copy) NSString *cerPath;//普通证书路径 开启证书功能必传（CA证书，其他非国密认证证书）
@property (nonatomic, strong) NSArray *gatewayAdrArray;//站点优选数组（开启站点优选必传）

@property (nonatomic, copy) NSString *tunnelBundleId;




/**
 将配置转换为字典类型
 @return 字典
 */
- (NSDictionary *)toDictionary;

/**
 将字典类型转换为配置

 @param dic 字典
 @return 配置信息对象
 */
+ (ConnectionConfiguration *)configurationWithDictionary:(NSDictionary *)dic;

@end
