//
//  TunnelManager.h
//  SecoSDKTunnel
//
//  Created by SDK on 2019/8/12.
//  Copyright © 2019年 Huawei. All rights reserved.
//

#import <Foundation/Foundation.h>
@import NetworkExtension;
NS_ASSUME_NONNULL_BEGIN

@interface TunnelManager : NEPacketTunnelProvider

- (void)startTunnelWithOptions:(NSDictionary *)options completionHandler:(void (^)(NSError *))completionHandler;
- (void)handleMessage:(NSData *)messageData completionHandler:(void (^)(NSData *))completionHandler;
- (void)stopWithReason:(NEProviderStopReason)reason completionHandler:(void (^)(void))completionHandler;
@end

NS_ASSUME_NONNULL_END
